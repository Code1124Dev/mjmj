# TeaHack Glass
Android Studio project. Open project, sync Gradle, Build > Build APK(s).
Features: draggable liquid-glass-styled overlay, persistent demonstration controls, Root availability test, kernel version display.
No game hooks, memory reading, ESP, aimbot, recoil modification, or anti-cheat bypass are implemented.
The visual style is an original liquid-glass-inspired interpretation, not an official Apple UI.
Note: Android 15 may enforce foreground-service startup restrictions; start overlay while app is in foreground.
