plugins { id("com.android.application") }
android {
 namespace = "com.teahack.glass"
 compileSdk = 35
 defaultConfig { applicationId = "com.teahack.glass"; minSdk = 29; targetSdk = 35; versionCode = 1; versionName = "1.0" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
