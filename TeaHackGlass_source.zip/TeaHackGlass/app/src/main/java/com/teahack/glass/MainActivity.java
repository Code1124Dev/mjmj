package com.teahack.glass;
import android.app.*;import android.os.*;import android.content.*;import android.net.Uri;import android.provider.Settings;import android.graphics.Color;import android.graphics.Typeface;import android.graphics.drawable.GradientDrawable;import android.view.*;import android.widget.*;
public class MainActivity extends Activity {
 int d(float v){return (int)(getResources().getDisplayMetrics().density*v+.5f);} 
 GradientDrawable bg(int c,int r){GradientDrawable x=new GradientDrawable();x.setColor(c);x.setCornerRadius(d(r));x.setStroke(d(1),0x55FFFFFF);return x;}
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(0xff090b17);getWindow().setNavigationBarColor(0xff090b17);
 LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setPadding(d(24),d(40),d(24),d(20));root.setBackgroundColor(0xff090b17);setContentView(root);
 TextView title=new TextView(this);title.setText("TeaHack  ◈  GLASS");title.setTextSize(29);title.setTypeface(null,Typeface.BOLD);title.setTextColor(-1);root.addView(title);
 TextView sub=new TextView(this);sub.setText("Liquid Glass · Android Control Center");sub.setTextColor(0xff9ba9d3);sub.setTextSize(14);root.addView(sub);
 TextView card=new TextView(this);card.setText("◉  设备状态\n\n内核："+System.getProperty("os.version")+"\n架构："+android.os.Build.SUPPORTED_ABIS[0]+"\nRoot：点击下方按钮检测");card.setTextColor(-1);card.setTextSize(15);card.setPadding(d(18),d(18),d(18),d(18));card.setBackground(bg(0xff20263d,26));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=d(32);root.addView(card,cp);
 Button check=new Button(this);check.setText("检测超级用户权限");root.addView(check);check.setOnClickListener(v->{new Thread(()->{boolean ok=false;try{Process p=new ProcessBuilder("su","-c","id").redirectErrorStream(true).start();ok=p.waitFor()==0;}catch(Exception ignored){}boolean finalOk=ok;runOnUiThread(()->Toast.makeText(this,finalOk?"Root 可用":"Root 不可用或授权被拒绝",Toast.LENGTH_LONG).show());}).start();});
 Button start=new Button(this);start.setText("启动液态玻璃悬浮窗");root.addView(start);start.setOnClickListener(v->{if(!Settings.canDrawOverlays(this)){Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()));startActivity(i);return;}try{startForegroundService(new Intent(this,GlassService.class));}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}});
 Button stop=new Button(this);stop.setText("关闭悬浮窗");root.addView(stop);stop.setOnClickListener(v->stopService(new Intent(this,GlassService.class)));
 TextView note=new TextView(this);note.setText("功能面板是交互原型。不会注入、读取或修改游戏进程，也不包含实际 ESP / Aimbot / Hook。\n\n部分游戏可能限制第三方悬浮窗显示。");note.setTextColor(0xffa9b4ce);note.setTextSize(13);LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);np.topMargin=d(22);root.addView(note,np);
 }
}
